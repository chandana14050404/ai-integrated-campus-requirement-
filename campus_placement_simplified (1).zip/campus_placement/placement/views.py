from functools import wraps

from django.contrib import messages
from django.contrib.auth import login as auth_login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.db.models import Count
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.utils import timezone

from .forms import (
    ExamAnswerForm, FeedbackForm, JobForm, QuestionForm, RegistrationForm,
    StudentProfileForm, TPOResponseForm,
)
from .ml_recommend import recommend_jobs
from .models import Feedback, Job, JobApplication, StudentProfile, User

SELECTION_THRESHOLD = 0.80  # >= 80% correct -> Selected, matching the brief


def role_required(*roles):
    """Restrict a view to users whose .role is in `roles`."""
    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def wrapped(request, *args, **kwargs):
            if request.user.role not in roles:
                messages.error(request, "You don't have access to that page.")
                return redirect('dashboard')
            return view_func(request, *args, **kwargs)
        return wrapped
    return decorator


# --------------------------------------------------------------------------
# Public pages
# --------------------------------------------------------------------------
def index(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    stats = {
        'open_jobs': Job.objects.filter(is_active=True, last_date__gte=timezone.localdate()).count(),
        'companies': User.objects.filter(role=User.Role.COMPANY).count(),
        'students': User.objects.filter(role=User.Role.STUDENT).count(),
    }
    return render(request, 'placement/index.html', {'stats': stats})


def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            messages.success(request, f'Welcome, {user.display_name()}! Your account has been created.')
            return redirect('dashboard')
    else:
        form = RegistrationForm()
    return render(request, 'placement/register.html', {'form': form})


class RoleAwareLoginView(LoginView):
    template_name = 'placement/login.html'

    def get_success_url(self):
        return reverse_lazy('dashboard')


@login_required
def dashboard(request):
    user = request.user
    if user.is_student():
        return redirect('student_home')
    if user.is_company():
        return redirect('company_home')
    if user.is_tpo():
        return redirect('tpo_home')
    return redirect('index')


# --------------------------------------------------------------------------
# Student views
# --------------------------------------------------------------------------
@role_required(User.Role.STUDENT)
def student_home(request):
    profile = getattr(request.user, 'student_profile', None)
    recent_applications = request.user.applications.select_related('job', 'job__company')[:5]
    open_feedback = request.user.feedback_entries.all()[:5]
    return render(request, 'placement/student/home.html', {
        'profile': profile,
        'recent_applications': recent_applications,
        'open_feedback': open_feedback,
    })


@role_required(User.Role.STUDENT)
def student_profile_edit(request):
    profile = getattr(request.user, 'student_profile', None)
    instance = profile or StudentProfile(user=request.user)
    if request.method == 'POST':
        form = StudentProfileForm(request.POST, request.FILES, instance=instance)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            form.save_m2m()
            messages.success(request, 'Profile saved successfully.')
            return redirect('student_home')
    else:
        form = StudentProfileForm(instance=instance)
    return render(request, 'placement/student/profile_form.html', {
        'form': form, 'is_update': profile is not None,
    })


@role_required(User.Role.STUDENT)
def student_recommendations(request):
    profile = getattr(request.user, 'student_profile', None)
    if profile is None:
        messages.warning(request, 'Please complete your profile first so we can recommend jobs.')
        return redirect('student_profile_edit')
    recommendations = recommend_jobs(request.user, k=8)
    return render(request, 'placement/student/recommendations.html', {
        'recommendations': recommendations,
        'profile': profile,
    })


@role_required(User.Role.STUDENT)
def student_apply_job(request, job_id):
    job = get_object_or_404(Job, id=job_id)

    if JobApplication.objects.filter(job=job, student=request.user).exists():
        messages.info(request, "You've already applied to this job.")
        return redirect('student_job_status')

    if not job.is_open():
        messages.error(request, 'This job is no longer accepting applications.')
        return redirect('student_recommendations')

    questions = list(job.questions.all())
    if not questions:
        messages.error(request, 'This company has not added a test for this job yet.')
        return redirect('student_recommendations')

    if request.method == 'POST':
        form = ExamAnswerForm(request.POST, questions=questions)
        if form.is_valid():
            correct = 0
            for q in questions:
                given = form.cleaned_data.get(f'question_{q.id}')
                if given == q.correct_option:
                    correct += 1
            score = correct / len(questions)
            status = (
                JobApplication.Status.SELECTED if score >= SELECTION_THRESHOLD
                else JobApplication.Status.REJECTED
            )
            JobApplication.objects.create(job=job, student=request.user, score=score, status=status)

            profile = getattr(request.user, 'student_profile', None)
            if profile is not None:
                profile.latest_score = score
                profile.save(update_fields=['latest_score'])

            messages.success(
                request,
                f'You scored {round(score * 100, 1)}%. Result: {status.title()}.'
            )
            return redirect('student_job_status')
    else:
        form = ExamAnswerForm(questions=questions)

    return render(request, 'placement/student/exam.html', {'job': job, 'form': form})


@role_required(User.Role.STUDENT)
def student_job_status(request):
    applications = request.user.applications.select_related('job', 'job__company')
    return render(request, 'placement/student/job_status.html', {'applications': applications})


@role_required(User.Role.STUDENT)
def student_feedback(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST, student=request.user)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.student = request.user
            feedback.save()
            messages.success(request, 'Your feedback has been submitted to the TPO.')
            return redirect('student_feedback')
    else:
        form = FeedbackForm(student=request.user)
    history = request.user.feedback_entries.select_related('job')
    return render(request, 'placement/student/feedback.html', {'form': form, 'history': history})


# --------------------------------------------------------------------------
# Company views
# --------------------------------------------------------------------------
@role_required(User.Role.COMPANY)
def company_home(request):
    jobs = request.user.jobs.annotate(num_applicants=Count('applications'))
    return render(request, 'placement/company/home.html', {'jobs': jobs})


@role_required(User.Role.COMPANY)
def company_post_job(request):
    if request.method == 'POST':
        form = JobForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.company = request.user
            job.save()
            form.save_m2m()
            messages.success(request, f'"{job.title}" has been posted (Job ID #{job.id}).')
            return redirect('company_add_questions', job_id=job.id)
    else:
        form = JobForm()
    return render(request, 'placement/company/post_job.html', {'form': form})


@role_required(User.Role.COMPANY)
def company_add_questions(request, job_id):
    job = get_object_or_404(Job, id=job_id, company=request.user)
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.job = job
            question.save()
            messages.success(request, 'Question added.')
            return redirect('company_add_questions', job_id=job.id)
    else:
        form = QuestionForm()
    questions = job.questions.all()
    return render(request, 'placement/company/add_questions.html', {
        'job': job, 'form': form, 'questions': questions,
    })


@role_required(User.Role.COMPANY)
def company_view_applicants(request, job_id):
    job = get_object_or_404(Job, id=job_id, company=request.user)
    applications = job.applications.select_related('student', 'student__student_profile')
    return render(request, 'placement/company/applicants.html', {
        'job': job, 'applications': applications,
    })


# --------------------------------------------------------------------------
# TPO views
# --------------------------------------------------------------------------
@role_required(User.Role.TPO)
def tpo_home(request):
    stats = {
        'students': User.objects.filter(role=User.Role.STUDENT).count(),
        'companies': User.objects.filter(role=User.Role.COMPANY).count(),
        'open_jobs': Job.objects.filter(is_active=True, last_date__gte=timezone.localdate()).count(),
        'selected': JobApplication.objects.filter(status=JobApplication.Status.SELECTED).count(),
        'rejected': JobApplication.objects.filter(status=JobApplication.Status.REJECTED).count(),
        'pending_feedback': Feedback.objects.filter(resolved=False).count(),
    }
    return render(request, 'placement/tpo/home.html', {'stats': stats})


@role_required(User.Role.TPO)
def tpo_feedback_list(request):
    feedback_qs = Feedback.objects.select_related('student', 'job').order_by('resolved', '-created_at')
    return render(request, 'placement/tpo/feedback_list.html', {'feedback_qs': feedback_qs})


@role_required(User.Role.TPO)
def tpo_feedback_respond(request, feedback_id):
    feedback = get_object_or_404(Feedback, id=feedback_id)
    if request.method == 'POST':
        form = TPOResponseForm(request.POST, instance=feedback)
        if form.is_valid():
            form.save()
            messages.success(request, 'Response saved.')
            return redirect('tpo_feedback_list')
    else:
        form = TPOResponseForm(instance=feedback)
    return render(request, 'placement/tpo/feedback_respond.html', {'feedback': feedback, 'form': form})


@role_required(User.Role.TPO)
def tpo_students(request):
    students = User.objects.filter(role=User.Role.STUDENT).select_related('student_profile')
    return render(request, 'placement/tpo/students.html', {'students': students})


@role_required(User.Role.TPO)
def tpo_companies(request):
    companies = User.objects.filter(role=User.Role.COMPANY).annotate(num_jobs=Count('jobs'))
    return render(request, 'placement/tpo/companies.html', {'companies': companies})
