"""
KNN-based job recommendation engine.

This implements the K-Nearest Neighbours approach described in the project
brief: a student's skill set is compared against every open job's required
skill set, and the K closest jobs are returned as recommendations.

Each job and the student are represented as binary vectors over the full
vocabulary of skills in the system (1 if the skill is required/possessed,
0 otherwise). scikit-learn's NearestNeighbors is fit on the job vectors
using cosine distance, then queried with the student's vector. Cosine
distance is a natural fit for sparse binary "set of skills" data — it is
the angle between two skill-sets and is unaffected by how many *extra*
skills a job or student lists, only by how much they overlap.

A job with zero overlapping skills is never recommended, even if it would
otherwise be one of the K nearest neighbours (cosine distance between two
disjoint binary vectors is technically undefined/maximal; we filter those
out explicitly with an overlap check rather than relying on the metric).
"""

from dataclasses import dataclass

from sklearn.neighbors import NearestNeighbors

from .models import Job, Skill


@dataclass
class Recommendation:
    job: Job
    match_score: float  # 0-100, percentage similarity

    @property
    def match_percent(self):
        return round(self.match_score, 1)


def _skill_vector(skill_ids, vocabulary):
    """Binary vector over `vocabulary` (ordered list of skill ids)."""
    skill_id_set = set(skill_ids)
    return [1 if skill_id in skill_id_set else 0 for skill_id in vocabulary]


def recommend_jobs(student_user, k=5):
    """
    Return up to `k` Recommendation objects for the given student,
    sorted by descending match score, excluding jobs the student has
    already applied to and jobs that are closed.
    """
    student_profile = getattr(student_user, 'student_profile', None)
    if student_profile is None:
        return []

    student_skill_ids = list(student_profile.skills.values_list('id', flat=True))
    if not student_skill_ids:
        return []

    already_applied_job_ids = set(
        student_user.applications.values_list('job_id', flat=True)
    )

    open_jobs = list(
        Job.objects.filter(is_active=True)
        .exclude(id__in=already_applied_job_ids)
        .prefetch_related('required_skills', 'company')
    )
    if not open_jobs:
        return []

    # Build the shared skill vocabulary from every skill in play.
    vocabulary = list(Skill.objects.order_by('id').values_list('id', flat=True))
    vocab_index = {skill_id: i for i, skill_id in enumerate(vocabulary)}

    job_vectors = []
    valid_jobs = []
    for job in open_jobs:
        if not job.is_open():
            continue
        req_skill_ids = list(job.required_skills.values_list('id', flat=True))
        if not req_skill_ids:
            continue
        job_vectors.append(_skill_vector(req_skill_ids, vocabulary))
        valid_jobs.append((job, set(req_skill_ids)))

    if not valid_jobs:
        return []

    student_vector = _skill_vector(student_skill_ids, vocabulary)

    n_neighbors = min(k, len(valid_jobs))
    model = NearestNeighbors(n_neighbors=n_neighbors, metric='cosine')
    model.fit(job_vectors)
    distances, indices = model.kneighbors([student_vector])

    student_skill_id_set = set(student_skill_ids)
    recommendations = []
    for distance, idx in zip(distances[0], indices[0]):
        job, req_skill_ids = valid_jobs[idx]
        overlap = req_skill_ids & student_skill_id_set
        if not overlap:
            continue  # no real overlap -> not a genuine recommendation
        similarity = max(0.0, 1.0 - distance) * 100
        recommendations.append(Recommendation(job=job, match_score=similarity))

    recommendations.sort(key=lambda r: r.match_score, reverse=True)
    return recommendations
