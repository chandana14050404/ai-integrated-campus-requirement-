from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import Feedback, Job, JobApplication, Question, Skill, StudentProfile, User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'role', 'email', 'company_name', 'is_staff')
    list_filter = ('role', 'is_staff', 'is_active')
    fieldsets = UserAdmin.fieldsets + (
        ('Placement details', {'fields': ('role', 'contact_number', 'address', 'company_name')}),
    )


@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    search_fields = ('name',)


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'qualification', 'percentage', 'passout_year', 'latest_score')
    search_fields = ('user__username',)


class QuestionInline(admin.TabularInline):
    model = Question
    extra = 0


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ('title', 'company', 'salary', 'posted_date', 'last_date', 'is_active')
    list_filter = ('is_active', 'company')
    search_fields = ('title', 'company__username', 'company__company_name')
    inlines = [QuestionInline]


@admin.register(JobApplication)
class JobApplicationAdmin(admin.ModelAdmin):
    list_display = ('student', 'job', 'score', 'status', 'applied_at')
    list_filter = ('status',)


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('student', 'job', 'created_at', 'resolved')
    list_filter = ('resolved',)
