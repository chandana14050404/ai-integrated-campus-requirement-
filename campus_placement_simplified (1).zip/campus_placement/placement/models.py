from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    """
    Custom user model that covers all three account types described in the
    project brief: Company, Student and TPO (Training & Placement Officer).
    Authentication, password hashing and sessions all come from Django's
    built-in auth system instead of hand-rolled SQL + plaintext passwords.
    """

    class Role(models.TextChoices):
        STUDENT = 'STUDENT', 'Student'
        COMPANY = 'COMPANY', 'Company'
        TPO = 'TPO', 'Training & Placement Officer'

    role = models.CharField(max_length=10, choices=Role.choices)
    contact_number = models.CharField(max_length=20, blank=True)
    address = models.CharField(max_length=255, blank=True)

    # Company-only display name (e.g. "Infosys Ltd"). Students/TPO just use
    # get_full_name()/username.
    company_name = models.CharField(max_length=150, blank=True)

    def is_student(self):
        return self.role == self.Role.STUDENT

    def is_company(self):
        return self.role == self.Role.COMPANY

    def is_tpo(self):
        return self.role == self.Role.TPO

    def display_name(self):
        if self.is_company() and self.company_name:
            return self.company_name
        return self.get_full_name() or self.username

    def __str__(self):
        return f'{self.username} ({self.get_role_display()})'


class Skill(models.Model):
    """A normalised skill tag, e.g. 'Python', 'SQL', 'Communication'."""

    name = models.CharField(max_length=60, unique=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class StudentProfile(models.Model):
    """Academic + resume profile, one per student account."""

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name='student_profile'
    )
    qualification = models.CharField(max_length=120, help_text='e.g. B.Tech Computer Science')
    percentage = models.DecimalField(
        max_digits=5, decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text='Aggregate percentage / CGPA*10'
    )
    passout_year = models.PositiveIntegerField(help_text='Year of graduation')
    experience = models.CharField(
        max_length=255, blank=True,
        help_text='Internships / prior work experience, if any'
    )
    resume = models.FileField(upload_to='resumes/', blank=True, null=True)
    skills = models.ManyToManyField(Skill, blank=True, related_name='students')

    # Latest aptitude/technical test score, expressed as a fraction (0-1),
    # mirroring the "score" column from the original design.
    latest_score = models.FloatField(default=0)

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Profile: {self.user.username}'

    def skill_names(self):
        return ', '.join(self.skills.values_list('name', flat=True))


class Job(models.Model):
    """A job posting created by a Company account."""

    company = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='jobs',
        limit_choices_to={'role': User.Role.COMPANY},
    )
    title = models.CharField(max_length=150)
    description = models.TextField()
    salary = models.CharField(max_length=80, help_text='e.g. "6 LPA" or "₹45,000/month"')
    required_skills = models.ManyToManyField(Skill, related_name='jobs')
    posted_date = models.DateField(default=timezone.now)
    last_date = models.DateField(help_text='Last date to apply')
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-posted_date']

    def __str__(self):
        return f'{self.title} @ {self.company.display_name()}'

    def is_open(self):
        return self.is_active and self.last_date >= timezone.localdate()

    def required_skill_names(self):
        return ', '.join(self.required_skills.values_list('name', flat=True))

    def applicant_count(self):
        return self.applications.count()


class Question(models.Model):
    """A single MCQ test question, tied to one specific job posting."""

    class CorrectOption(models.TextChoices):
        A = 'A', 'Option A'
        B = 'B', 'Option B'
        C = 'C', 'Option C'
        D = 'D', 'Option D'

    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='questions')
    question_text = models.CharField(max_length=500)
    option_a = models.CharField(max_length=200)
    option_b = models.CharField(max_length=200)
    option_c = models.CharField(max_length=200)
    option_d = models.CharField(max_length=200)
    correct_option = models.CharField(max_length=1, choices=CorrectOption.choices)

    def __str__(self):
        return f'Q for {self.job.title}: {self.question_text[:40]}'

    def option_text(self, letter):
        return getattr(self, f'option_{letter.lower()}')


class JobApplication(models.Model):
    """Records a student's application + exam outcome for one job."""

    class Status(models.TextChoices):
        SELECTED = 'SELECTED', 'Selected'
        REJECTED = 'REJECTED', 'Rejected'

    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='applications')
    student = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='applications',
        limit_choices_to={'role': User.Role.STUDENT},
    )
    applied_at = models.DateTimeField(auto_now_add=True)
    score = models.FloatField(help_text='Fraction of correct answers, 0.0 - 1.0')
    status = models.CharField(max_length=10, choices=Status.choices)

    class Meta:
        unique_together = ('job', 'student')
        ordering = ['-applied_at']

    def __str__(self):
        return f'{self.student.username} -> {self.job.title} ({self.status})'

    def score_percent(self):
        return round(self.score * 100, 1)


class Feedback(models.Model):
    """A student's feedback / challenge raised about exams or interviews."""

    student = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='feedback_entries',
        limit_choices_to={'role': User.Role.STUDENT},
    )
    job = models.ForeignKey(
        Job, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='feedback_entries',
    )
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)
    tpo_response = models.TextField(blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'Feedback from {self.student.username}'
