from datetime import date

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.validators import FileExtensionValidator

from .models import Feedback, Job, Question, Skill, StudentProfile, User


# --------------------------------------------------------------------------
# Auth
# --------------------------------------------------------------------------
class RegistrationForm(UserCreationForm):
    """
    Single sign-up form covering all three roles, matching the project's
    "New User Sign Up" screen (username, password, contact, email, address,
    user type). Django handles password validation + hashing for us.
    """

    role = forms.ChoiceField(choices=User.Role.choices, label='Register as')
    email = forms.EmailField(required=True)
    contact_number = forms.CharField(max_length=20, label='Contact number')
    address = forms.CharField(widget=forms.Textarea(attrs={'rows': 2}), required=False)
    first_name = forms.CharField(max_length=60, label='Full name (or contact person)')
    company_name = forms.CharField(
        max_length=150, required=False,
        help_text='Required if registering as a Company'
    )

    class Meta:
        model = User
        fields = [
            'username', 'first_name', 'email', 'contact_number', 'address',
            'role', 'company_name', 'password1', 'password2',
        ]

    def clean(self):
        cleaned = super().clean()
        role = cleaned.get('role')
        company_name = cleaned.get('company_name')
        if role == User.Role.COMPANY and not company_name:
            self.add_error('company_name', 'Company name is required for Company accounts.')
        return cleaned

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = self.cleaned_data['role']
        user.contact_number = self.cleaned_data['contact_number']
        user.address = self.cleaned_data.get('address', '')
        user.company_name = self.cleaned_data.get('company_name', '')
        if commit:
            user.save()
        return user


# --------------------------------------------------------------------------
# Student profile
# --------------------------------------------------------------------------
class StudentProfileForm(forms.ModelForm):
    skills = forms.ModelMultipleChoiceField(
        queryset=Skill.objects.all(),
        widget=forms.SelectMultiple(attrs={'size': 8}),
        help_text='Hold Ctrl (Cmd on Mac) to select multiple skills.',
    )
    resume = forms.FileField(
        required=False,
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx'])],
        help_text='PDF or Word document, up to 5 MB.',
    )

    class Meta:
        model = StudentProfile
        fields = ['qualification', 'percentage', 'passout_year', 'experience', 'resume', 'skills']
        widgets = {
            'qualification': forms.TextInput(attrs={'placeholder': 'e.g. B.Tech Computer Science'}),
            'experience': forms.TextInput(attrs={'placeholder': 'e.g. 6-month internship at XYZ (optional)'}),
        }

    def clean_resume(self):
        resume = self.cleaned_data.get('resume')
        if resume and resume.size > 5 * 1024 * 1024:
            raise forms.ValidationError('Resume file must be 5 MB or smaller.')
        return resume


# --------------------------------------------------------------------------
# Company: jobs & questions
# --------------------------------------------------------------------------
class JobForm(forms.ModelForm):
    required_skills = forms.ModelMultipleChoiceField(
        queryset=Skill.objects.all(),
        widget=forms.SelectMultiple(attrs={'size': 8}),
        help_text='Hold Ctrl (Cmd on Mac) to select multiple skills.',
    )
    last_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        label='Last date to apply',
    )

    class Meta:
        model = Job
        fields = ['title', 'description', 'salary', 'required_skills', 'last_date']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
            'title': forms.TextInput(attrs={'placeholder': 'e.g. Software Engineer Trainee'}),
            'salary': forms.TextInput(attrs={'placeholder': 'e.g. 6 LPA'}),
        }

    def clean_last_date(self):
        last_date = self.cleaned_data['last_date']
        if last_date < date.today():
            raise forms.ValidationError('Last date to apply cannot be in the past.')
        return last_date


class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_option']
        widgets = {
            'question_text': forms.Textarea(attrs={'rows': 2}),
        }


# --------------------------------------------------------------------------
# Student: take the test
# --------------------------------------------------------------------------
class ExamAnswerForm(forms.Form):
    """Dynamically built in the view: one ChoiceField per Question."""

    def __init__(self, *args, questions=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.question_ids = []
        for q in questions:
            field_name = f'question_{q.id}'
            self.fields[field_name] = forms.ChoiceField(
                label=q.question_text,
                choices=[
                    ('A', q.option_a),
                    ('B', q.option_b),
                    ('C', q.option_c),
                    ('D', q.option_d),
                ],
                widget=forms.RadioSelect,
                required=True,
            )
            self.question_ids.append(q.id)


# --------------------------------------------------------------------------
# Feedback
# --------------------------------------------------------------------------
class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['job', 'message']
        widgets = {
            'message': forms.Textarea(attrs={
                'rows': 4,
                'placeholder': 'Describe the challenge you faced during an exam or interview...'
            }),
        }

    def __init__(self, *args, student=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['job'].required = False
        self.fields['job'].label = 'Related job (optional)'
        if student is not None:
            self.fields['job'].queryset = Job.objects.filter(
                applications__student=student
            ).distinct()


class TPOResponseForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['tpo_response', 'resolved']
        widgets = {
            'tpo_response': forms.Textarea(attrs={'rows': 3}),
        }
