from django.contrib.auth.views import LogoutView
from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.RoleAwareLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # Student
    path('student/', views.student_home, name='student_home'),
    path('student/profile/', views.student_profile_edit, name='student_profile_edit'),
    path('student/recommendations/', views.student_recommendations, name='student_recommendations'),
    path('student/jobs/<int:job_id>/apply/', views.student_apply_job, name='student_apply_job'),
    path('student/status/', views.student_job_status, name='student_job_status'),
    path('student/feedback/', views.student_feedback, name='student_feedback'),

    # Company
    path('company/', views.company_home, name='company_home'),
    path('company/jobs/new/', views.company_post_job, name='company_post_job'),
    path('company/jobs/<int:job_id>/questions/', views.company_add_questions, name='company_add_questions'),
    path('company/jobs/<int:job_id>/applicants/', views.company_view_applicants, name='company_view_applicants'),

    # TPO
    path('tpo/', views.tpo_home, name='tpo_home'),
    path('tpo/feedback/', views.tpo_feedback_list, name='tpo_feedback_list'),
    path('tpo/feedback/<int:feedback_id>/respond/', views.tpo_feedback_respond, name='tpo_feedback_respond'),
    path('tpo/students/', views.tpo_students, name='tpo_students'),
    path('tpo/companies/', views.tpo_companies, name='tpo_companies'),
]
