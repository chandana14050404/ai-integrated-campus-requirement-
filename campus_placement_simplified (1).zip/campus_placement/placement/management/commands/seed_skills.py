from django.core.management.base import BaseCommand

from placement.models import Skill

DEFAULT_SKILLS = [
    'Python', 'Java', 'C++', 'C', 'JavaScript', 'SQL', 'MySQL', 'Django',
    'Flask', 'React', 'Node.js', 'HTML/CSS', 'Machine Learning', 'Data Analysis',
    'Pandas', 'NumPy', 'TensorFlow', 'AWS', 'Git', 'Linux', 'DSA',
    'Communication', 'Networking', 'DBMS', 'Operating Systems', 'Excel',
    'Power BI', 'Android', 'REST APIs', 'Testing/QA',
]


class Command(BaseCommand):
    help = 'Seed a starter list of skills used across job postings and student profiles.'

    def handle(self, *args, **options):
        created = 0
        for name in DEFAULT_SKILLS:
            _, was_created = Skill.objects.get_or_create(name=name)
            if was_created:
                created += 1
        self.stdout.write(self.style.SUCCESS(
            f'Done. {created} new skill(s) created, {len(DEFAULT_SKILLS) - created} already existed.'
        ))
